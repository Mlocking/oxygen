=== Hydrogen Pack ===
Tags: oxygen builder, hydrogen pack, copy and paste
Requires at least: 4.5
Tested up to: 5.5.1
Requires PHP: 7.0
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

A Pack of time-saving Oxygen Builder enhancements

== Description ==
Hydrogen pack is a collection of time-saving features for the great Oxygen builder plugin, these features include global clipboard management, contextual menu, user interface enhancements, etc.

Please visit the [Hydrogen Pack](https://www.erropix.com/products/hydrogen-pack/) page for more details

== Changelog ==

= 1.2.0 =
-   Editor sandbox mode
-   Added separate folder name options for classes and colors copied from external sites
-   Added a shape divider processor for custom SVG code
-   Added keyboard shortcuts for switching between PHP, CSS, and JS code of a code block
-   Added copy conditions
-   Added "edit content" shortcut
-   Updated default shortcuts for Mac compatibility
-   Fixed the copy of icon styles, so it doesn't override the selected icon in the target
-   Fixed a bug related to the structure panel enhancements in Safari
-   Minor UI improvements

= 1.1.3 =

-   Fixed a javascript bug in Safari that break Hydrogen Pack scripts
-   Added New icons for the structure panel elements
-   Decreased the structure panel icons size from 16px to 14px
-   Changed icons color for better contrast with the elements name

= 1.1.2 =

-   Added a reset button for each of the advanced styling sections
-   Implemented the new Clipboard API for Chrome browser
-   New option to set custom structure panel width
-   New option to open structure panel on load
-   New option to expand structure panel items on load
-   New option to show elements icons in the structure panel
-   New option to disable the structure panel compact mode

= 1.1.1 =

-   Enhanced link management for the inline content editor
-   Changed the color of the DELETE menu item to red
-   Allowed save shortcut to run inside code editor and text fields
-   Added new shortcut to activate the parent element
-   Added new shortcut to manage element conditions
-   Added new shortcuts to toggle advanced style tabs
-   Added new shortcuts to quickly open the frontend and backend
-   Fixed admin menu not registered before license activation
-   Fixed missing names after pasting styles from newly created components

= 1.1.0 =

-   New Adaptive Shortcuts Picker
-   Copy and paste full pages
-   Copy and paste element styles
-   11 new shortcuts to access important panels (disabled by default)
-   New shortcuts for next and previous media breakpoints
-   Double click on structure panel items to rename element
-   New CSS tweaks to enhance the structure panel
-   Added export and import for Hydrogen Pack settings
-   Fixed the conditions modal height issue
-   Added a flashing animation to elements after successful copy
-   Display a loading overlay while processing components during import
-   Various code optimization to avoid some issues reported in previous versions

= 1.0.3 =

-   Added a settings page to enable and customize features
-   Added new shortcuts to switch media breakpoints
-   Ability to transform imported external media images to URL based
-   Added an option to keep the current element active after pasting elements
-   Added an option to disable the Oxygen edit locking system
-   The contextual menu can be shown using the dedicated keyboard key
-   Fixed a bug that prevented copy/paste of elements containing special Unicode characters

= 1.0.2 =

-   Fixed compatibility issues with Editor Enhancer Pro
-   Fixed page scrolling to top when you copy an element
-   Fixed structure panel not updating when you move elements up/down
-   Improved keyboard shortcuts handling on all browsers
-   Disabled keyboard shortcuts inside text fields or when editing text elements

= 1.0.1 =

-   Fixed copy to clipboard not working for some users
-   Restored the structure panel actions
-   Using the ctrl/cmd+A will now auto focus on the components search box

= 1.0.0 =

-   Initial release
