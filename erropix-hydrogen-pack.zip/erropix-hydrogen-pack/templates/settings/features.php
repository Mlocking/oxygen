<section class="section">
    <div class="section-header">
        <h3 class="section-title">Enable Features</h3>
    </div>

    <div class="section-body">
        <?php
        $features = [
            'contextMenu' => [
                "label" => "Right-click menu",
                "haveOptions" => true,
            ],
            'clipboard' => [
                "label" => "Clipboard",
                "haveOptions" => true,
            ],
            'shortcuts' => [
                "label" => "Keyboard shortcuts",
                "haveOptions" => true,
            ],
            'conditionsEnhancer' => [
                "label" => "Enhanced conditions dialog",
                "haveOptions" => false,
            ],
            'structureEnhancer' => [
                "label" => "Enhanced structure panel",
                "haveOptions" => true,
            ],
            'contentEditorEnhancer' => [
                "label" => "Enhanced content editor",
                "haveOptions" => false,
            ],
            'advancedStylesReset' => [
                "label" => "Advanced styles reset",
                "haveOptions" => false,
            ],
            'disableEditLocking' => [
                "label" => "Disable edit locking",
                "haveOptions" => false,
            ],
        ];

        $features = apply_filters("hydrogen_settings_features", $features);

        foreach ($features as $key => $feature) :
            $name = "settings[$key][enabled]";
            $value = $settings->$key->enabled;
            $id = $ui->nameToId($name);
        ?>
            <div class="field">
                <div class="field-label">
                    <label for="<?= $id ?>"><?= $feature["label"] ?></label>
                </div>
                <div class="field-control">
                    <?= $ui->checkbox($name, $value) ?>

                    <?php if ($feature["haveOptions"]) : ?>
                        <a href="#section-<?= strtolower($key) ?>" class="scroll-to-section">
                            <span class="dashicons dashicons-admin-generic" data-dependon="#<?= $id ?>"></span>
                        </a>
                    <?php endif ?>
                </div>
            </div>
        <?php endforeach ?>
    </div>
</section>