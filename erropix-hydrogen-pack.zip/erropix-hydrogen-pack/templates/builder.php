<div hydrogen-pack>
    <?php if ($settings->contentEditorEnhancer->enabled) : ?>
        <textarea id="hydrogen-link-input" style="display:none;"></textarea>
    <?php endif ?>

    <?php if ($settings->conditionsEnhancer->enabled) : ?>
        <script type="text/template" id="tpl-conditions-modal-header">
            <div>
                Show element if
                <label class="condition-type-toggle" ng-class="{'active':iframeScope.getOption('conditionstype')==''}">
                    <input type="radio" name="conditions_type" value="1" ng-model="iframeScope.component.options[iframeScope.component.active.id]['model']['conditionstype']" ng-change="iframeScope.setOption(iframeScope.component.active.id, iframeScope.component.active.name,'conditionstype');iframeScope.checkResizeBoxOptions('conditionstype'); evalGlobalConditions(); evalGlobalConditionsInList()"> ALL
                </label>
                <label class="condition-type-toggle" ng-class="{'active':iframeScope.getOption('conditionstype')=='1'}">
                    <input type="radio" name="conditions_type" value="" ng-model="iframeScope.component.options[iframeScope.component.active.id]['model']['conditionstype']" ng-change="iframeScope.setOption(iframeScope.component.active.id, iframeScope.component.active.name,'conditionstype');iframeScope.checkResizeBoxOptions('conditionstype'); evalGlobalConditions(); evalGlobalConditionsInList()"> ANY
                </label>
                of these conditions are true
            </div>
            <svg class="oxygen-close-icon" ng-click="hideDialogWindow()">
                <use xlink:href="#oxy-icon-cross"></use>
            </svg>
        </script>
    <?php endif ?>
</div>