<style>
    #pframe,
    #fs_account .postbox:not(:first-child),
    #fs_account .fs-header-actions a[href='#fs_billing'],
    #fs_account_details .fs-field-user_name form,
    #fs_account_details .fs-field-email form,
    #fs_account_details .fs-field-site_public_key,
    #fs_account_details .fs-field-site_secret_key,
    #fs_account_details .fs-field-plan .button-group,
    #fs_account_details .fs-field-license_key .fs-toggle-visibility,
    #fs_account_details .fs-field-license_key button {
        display: none;
    }
</style>